<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Press</title>
<meta name="description" content="Read about Wrevel in the news. Learn more about Wrevel in the press.">
<meta name="keywords" content="event hosting, parties, new york city, tickets, wrevel, online tickets, press, news, buy tickets, publication, press page">
<link href="<? echo $PATH_BOOTSTRAP?>css/bootstrap.css" rel="stylesheet">
<link href="<? echo $PATH_BOOTSTRAP?>css/bootstrap.min.css" rel="stylesheet">
<link href="<? echo $PATH_BOOTSTRAP?>css/bootstrap-theme.css" rel="stylesheet">
<link href="<? echo $PATH_BOOTSTRAP?>css/bootstrap-theme.min.css" rel="stylesheet">
<link href="<? echo $PATH_BOOTSTRAP?>css/main.css" rel="stylesheet">
<link href="//netdna.bootstrapcdn.com/font-awesome/4.1.0/css/font-awesome.min.css" rel="stylesheet">
</head>

<body>

<?php $this->load->view('header');?>

<!--content
==============================================-->

<!--Press-->
  
    	    <center><div>
	    <h1 style="text-align:center;font-size:40px;font-family:GillSans;color:white;"><img src="<?php echo $PATH_IMG?>w1.png"/>Press</h1>
	    </div></center>
	
<div class="container" style="width: 90%;">
<div class="col-md-offset-1 col-md-10" style="margin-top: 40px;">
<!--DNA-->
	<div class="row">      
	
	<div class="col-md-6">   
        <div class="panel" style="border:none; border-radius: 10px;">
           <div class="panel-body" style="background: filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#6f95ae', endColorstr='#adc2d0', GradientType='0'); /*IE*/
background: -ms-linear-gradient(top, #6f95ae, #adc2d0);       /* IE 10 */
background: -o-linear-gradient(top, #6f95ae,#adc2d0);  /* Opera 11.10+*/ 
background:-moz-linear-gradient(top,#6f95ae,#adc2d0); 
background: -webkit-linear-gradient(top, #6f95ae,#adc2d0);   /*Safari5.1 Chrome10+*/
background:-webkit-gradient(linear, 0% 0%, 0% 100%,from(#6f95ae), to(#adc2d0));
	-moz-box-shadow:2px 2px 2px rgba(0, 0, 0, .2);-webkit-box-shadow: 2px 2px 2px rgba(0, 0, 0, .2);box-shadow:2px 2px 2px rgba(0, 0, 0, .2);
	border-radius: 10px;padding-bottom: 20px;border-color: transparent;">
		    <center><img src="<?php echo $PATH_IMG?>bkpaper.png" style="width:50%; margin-top: 15px;padding:8px;"/></center>
		    <center><img src="<?php echo $PATH_IMG?>bkpaperimage.jpg" style="width:81%; margin-top: 25px;"/></center>
		    <p style="text-align: center; width: 75%; margin-left: 50px; margin-top: 10px; color: white; font-size: 20px;">"Greenpoint startup wants to be Facebook with will-call"</p>
		    <center><a href="http://www.brooklynpaper.com/stories/37/44/cl-wrevel-greenpoint-facebook-2014-10-31-bk_37_44.html" target="_blank"><button type="submit" class="btn btn-primary btn-lg" style="border:none; background: #678faa">Read More</button></a></center>
		
	    </div>
        </div>
	</div>
	<div class="col-md-6">   
        <div class="panel" style="border:none; border-radius: 10px;">
           <div class="panel-body" style="background: filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#6f95ae', endColorstr='#adc2d0', GradientType='0'); /*IE*/
background: -ms-linear-gradient(top, #6f95ae, #adc2d0);       /* IE 10 */
background: -o-linear-gradient(top, #6f95ae,#adc2d0);  /* Opera 11.10+*/ 
background:-moz-linear-gradient(top,#6f95ae,#adc2d0); 
background: -webkit-linear-gradient(top, #6f95ae,#adc2d0);   /*Safari5.1 Chrome10+*/
background:-webkit-gradient(linear, 0% 0%, 0% 100%,from(#6f95ae), to(#adc2d0));
	-moz-box-shadow:2px 2px 2px rgba(0, 0, 0, .2);-webkit-box-shadow: 2px 2px 2px rgba(0, 0, 0, .2);box-shadow:2px 2px 2px rgba(0, 0, 0, .2);
	border-radius: 10px;padding-bottom: 20px;border-color: transparent;">
		    <center><img src="<?php echo $PATH_IMG?>greenpointgazette_icon.png" style="width:50%; margin-top: 15px;"/></center>
		    <center><img src="<?php echo $PATH_IMG?>greenpoint_gazette_pic1.jpg" style="width:70%; margin-top: 20px;"/></center>
		    <p style="text-align: center; width: 75%; margin-left: 50px; margin-top: 10px; color: white; font-size: 20px;">"Wrevel To Relauch With Exhaustive Partying Options"</p>
		    <center><a href="http://www.greenpointnews.com/entertainment/6332/wrevel-to-relauch-with-exhaustive-partying-options" target="_blank"><button type="submit" class="btn btn-primary btn-lg" style="border: none;background: #678faa">Read More</button></a></center>
		
	    </div>
        </div>
	</div>
	</div>
	<div class="row">	
	<div class="col-md-6">   
        <div class="panel" style="border:none;  border-radius: 10px;">
           <div class="panel-body" style="background: filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#6f95ae', endColorstr='#adc2d0', GradientType='0'); /*IE*/
background: -ms-linear-gradient(top, #6f95ae, #adc2d0);       /* IE 10 */
background: -o-linear-gradient(top, #6f95ae,#adc2d0);  /* Opera 11.10+*/ 
background:-moz-linear-gradient(top,#6f95ae,#adc2d0); 
background: -webkit-linear-gradient(top, #6f95ae,#adc2d0);   /*Safari5.1 Chrome10+*/
background:-webkit-gradient(linear, 0% 0%, 0% 100%,from(#6f95ae), to(#adc2d0));
	-moz-box-shadow:2px 2px 2px rgba(0, 0, 0, .2);-webkit-box-shadow: 2px 2px 2px rgba(0, 0, 0, .2);box-shadow:2px 2px 2px rgba(0, 0, 0, .2);
	border-radius: 10px;padding-bottom: 20px;border-color: transparent;">
		    <center><img src="<?php echo $PATH_IMG?>technically_icon.png" style="width:50%; margin-top: 5px;"/></center>
		    <center><img src="<?php echo $PATH_IMG?>technically.jpg" style="width:80%; margin-top: 15px;"/></center>
		    <p style="text-align: center; margin-top: 10px; color: white; font-size: 20px;">"8 Brooklyn Ventures we saw at Pier 92, New York Tech Day 2014"</p>
		    <center><a href="http://technical.ly/brooklyn/2014/04/28/8-brooklyn-ventures-saw-pier-92-new-york-tech-day-2014/" target="_blank"><button type="submit" class="btn btn-primary btn-lg" style="border:none; background: #678faa">Read More</button></a></center>
		
	    </div>
        </div>
	</div>
			
	<div class="col-md-6">   
        <div class="panel" style="border:none;  border-radius: 10px;">
           <div class="panel-body" style="background: filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#6f95ae', endColorstr='#adc2d0', GradientType='0'); /*IE*/
background: -ms-linear-gradient(top, #6f95ae, #adc2d0);       /* IE 10 */
background: -o-linear-gradient(top, #6f95ae,#adc2d0);  /* Opera 11.10+*/ 
background:-moz-linear-gradient(top,#6f95ae,#adc2d0); 
background: -webkit-linear-gradient(top, #6f95ae,#adc2d0);   /*Safari5.1 Chrome10+*/
background:-webkit-gradient(linear, 0% 0%, 0% 100%,from(#6f95ae), to(#adc2d0));
	-moz-box-shadow:2px 2px 2px rgba(0, 0, 0, .2);-webkit-box-shadow: 2px 2px 2px rgba(0, 0, 0, .2);box-shadow:2px 2px 2px rgba(0, 0, 0, .2);
	border-radius: 10px;padding-bottom: 20px;border-color: transparent;">
		    <center><img src="<?php echo $PATH_IMG?>greenpointgazette_icon.png" style="width:50%; margin-top: 21px;"/></center>
		    <center><img src="<?php echo $PATH_IMG?>greenpoint_gazette_pic_2.jpg" style="width:70%; margin-top: 21px;"/></center>
		    <p style="text-align: center; margin-top: 10px; color: white; font-size: 20px;">"New Greenpoint Company Wants to Tell You Where the Party Is!!!"</p>
		    <center><a href="http://www.greenpointnews.com/entertainment/5594/new-greenpoint-company-wants-to-tell-you-where-the-party-is" target="_blank"><button type="submit" class="btn btn-primary btn-lg" style="border:none; background: #678faa">Read More</button></a></center>
		
	    </div>
        </div>
	</div>
	</div>
	<div class="row">
	<div class="col-md-6">   
        <div class="panel" style="border:none; border-radius: 10px;">
           <div class="panel-body" style="background: filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#6f95ae', endColorstr='#adc2d0', GradientType='0'); /*IE*/
background: -ms-linear-gradient(top, #6f95ae, #adc2d0);       /* IE 10 */
background: -o-linear-gradient(top, #6f95ae,#adc2d0);  /* Opera 11.10+*/ 
background:-moz-linear-gradient(top,#6f95ae,#adc2d0); 
background: -webkit-linear-gradient(top, #6f95ae,#adc2d0);   /*Safari5.1 Chrome10+*/
background:-webkit-gradient(linear, 0% 0%, 0% 100%,from(#6f95ae), to(#adc2d0));
	-moz-box-shadow:2px 2px 2px rgba(0, 0, 0, .2);-webkit-box-shadow: 2px 2px 2px rgba(0, 0, 0, .2);box-shadow:2px 2px 2px rgba(0, 0, 0, .2);
	border-radius: 10px;padding-bottom: 20px;border-color: transparent;">
		    <center><img src="<?php echo $PATH_IMG?>dnainfo_icon.png" style="width:50%; margin-top: 15px;"/></center>
		    <center><img src="<?php echo $PATH_IMG?>dnainfo.jpg" style="width:81%; margin-top: 25px;"/></center>
		    <p style="text-align: center; width: 75%; margin-left: 50px; margin-top: 10px; color: white; font-size: 20px;">"New Party-Finding App Helps Eager Revelers Find Their Match"</p>
		    <center><a href="http://www.dnainfo.com/new-york/20130826/greenpoint/new-party-finding-app-helps-eager-revelers-find-their-match" target="_blank"><button type="submit" class="btn btn-primary btn-lg" style="border:none; background: #678faa">Read More</button></a></center>
		
	    </div>
        </div>
	</div>
	</div>
	<!--<center><button type="submit" class="btn btn-primary btn-lg" style="background: transparent; border-color: #414042; color: #414042; font-size: 25px;">Click for more</button></center>-->
	
	
<!--What to do-->
	<div class="col-md-12" style="padding-bottom:20px;">
        <div class="panel" style="margin-top: 40px;background-color: #71acd2; border:none;  border-radius: 10px;">
           <div class="panel-body" style="background: filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#6f95ae', endColorstr='#adc2d0', GradientType='0'); /*IE*/
background: -ms-linear-gradient(top, #6f95ae, #a6bbcb);       /* IE 10 */
background: -o-linear-gradient(top, #6f95ae,#a6bbcb);  /* Opera 11.10+*/ 
background:-moz-linear-gradient(top,#6f95ae,#a6bbcb); 
background: -webkit-linear-gradient(top, #6f95ae,#a6bbcb);   /*Safari5.1 Chrome10+*/
background:-webkit-gradient(linear, 0% 0%, 0% 100%,from(#6f95ae), to(#a6bbcb));
	-moz-box-shadow:2px 2px 2px rgba(0, 0, 0, .2);-webkit-box-shadow: 2px 2px 2px rgba(0, 0, 0, .2);box-shadow:2px 2px 2px rgba(0, 0, 0, .2);
	border-radius: 10px;">
		<p style="text-align: center;padding-top: 10px; color:white; font-size:25px;">What to do a feature on us? Contact us at publicrelations@wrevel.com.</p>
            </div>
        </div>
        </div>
    
</div>
</div>
<!--end of content-->

<?php $this->load->view('footer');?>

 <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <!--<script src="https://code.jquery.com/jquery.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>  
   
    <script src="<?php echo $PATH_BOOTSTRAP?>js/bootstrap.js"></script>-->
    <script src="<? echo $PATH_BOOTSTRAP?>js/dropdown.js"></script>
    <script src="<?php echo $PATH_JAVASCRIPT?>Notifications.js"></script>
</body>
</html> 