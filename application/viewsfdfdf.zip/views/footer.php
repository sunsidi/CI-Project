<!doctype html>
<html>
<head>
<meta charset="utf-8">
<style>
@media screen and (max-width:990px){
	div.aceg{
	display:none;
	}
}
</style>
</head>
<body>
<!--footer
==================================================-->
 <div id="footer navbar-fixed-bottom"  style="background:#A5B9CB;">
      <div class="row" style="padding:20px;">	
		<div class="col-md-4" style="text-align:center;margin-top:10px;">
			<img src="<?php echo $PATH_IMG?>wrevel_logo.png" style="width:207px;"/>
			<p style="font-size:25px; margin-top:10px;color:white;">
				<a href="https://www.facebook.com/wrevelinc" style="color:white;"><i class="fa fa-facebook" style="padding:20px 15px;"></i></a>
				<a href="https://twitter.com/wrevelco" style="color:white;"><i class="fa fa-twitter" style="padding:20px 15px;"></i></a>
				<a href="http://instagram.com/wrevel" style="color:white;"><i class="fa fa-instagram" style="padding:20px 15px;"></i></a>
				<a href="http://wrevel.tumblr.com" style="color:white;"><i class="fa fa-tumblr" style="padding:20px 15px;"></i></a>
				<a href="http://www.youtube.com/wrevelinc" style="color:white;"><i class="fa fa-youtube" style="padding:20px 15px;"></i></a>
			</p>
			<p class="copy_right">&copy; Wrevel, Inc.</p>
		</div>
		<div class="col-md-8">
		<div class="aceg">
			<div class="col-md-4">
			<ul class="links">
				<li>Company.</li>
				<li><a href="<?php echo base_url().'info/aboutus'?>">About Us</a></li>
				<li><a href="<?php echo base_url().'info/blog'?>">Blog</a></li>
				<li><a href="<?php echo base_url().'info/press'?>">Press</a></li>
				<li><a href="<?php echo base_url().'info/terms'?>">Terms of Use</a></li>
				<li><a href="<?php echo base_url().'info/privacy'?>">Privacy Policy</a></li>
			</ul>
			</div>
			<div class="col-md-4">
			<ul class="links">
				<li>Discover.</li>
				<li><a href="<?php echo base_url().'info/HowItWorks'?>">How Wrevel Works</a></li>
				<li><a href="<?php echo base_url().'wrevenues/wrevenues_main'?>">Wrevenues</a></li>
				<li><a href="<?php echo base_url().'info/pricing'?>">Pricing</a></li>
				<li><a href="<?php echo base_url().'info/FAQ'?>">F.A.Q.</a></li>
			</ul>
			</div>
			<div class="col-md-4">
			<ul class="links">
				<li>Reach.</li>
				<li><a href="<?php echo base_url().'info/partners'?>">Partners</a></li>
				<li><a href="<?php echo base_url().'info/nation'?>">Nation</a></li>
				<li><a href="<?php echo base_url().'info/careers'?>">Careers</a></li>
				<li><a href="<?php echo base_url().'info/contactus'?>">Contact Us</a></li>
			</ul>
			</div>
		</div>
		</div>
		      		<center><div class="header-link">
		<a href="<?php echo base_url().'info/aboutus'?>" style="color:white; font-size:20px;">About Us.</a>
		<a href="<?php echo base_url().'info/terms'?>" style="color:white; font-size:20px;">Terms of Use.</a>
		<a href="<?php echo base_url().'info/privacy'?>" style="color:white; font-size:20px;">Privacy Policy.</a>
		<a href="<?php echo base_url().'wrevenues/wrevenues_main'?>" style="color:white; font-size:20px;">Wrevenues.</a>
		<a href="<?php echo base_url().'info/pricing'?>" style="color:white; font-size:20px;">Pricing.</a>
		<a href="<?php echo base_url().'info/contactus'?>" style="color:white; font-size:20px; padding-bottom:20px;">Contact Us.</a>
		</div></center>
	</div> 
</div> 
		<!-- END OF FOOTER-->
</body>
</html>