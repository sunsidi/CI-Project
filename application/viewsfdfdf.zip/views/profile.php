<?php
        echo "Your info!<br>";
       	echo "Birthday: ".$birthday. "<br>";
        echo "Full Name: ".$full_name. "<br>";
        echo "Education: ". $education. "<br>";
        
        
       // echo $info;
        
?>